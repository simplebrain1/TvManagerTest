package com.coocaa.alarmslibrary;

public class Constant {
    public static String ALARM_ALERT_ACTION= "com.coocaa.os.process.ALARM_ALERT";
}
